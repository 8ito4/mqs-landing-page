<?php

// Forward Vercel requests to Laravel's public/index.php
require __DIR__ . '/../public/index.php'; 